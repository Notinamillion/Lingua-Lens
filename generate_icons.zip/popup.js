// Popup UI logic for Language Learning Extension

document.addEventListener('DOMContentLoaded', async () => {
  // Load settings and words
  await loadSettings();
  await loadWords();
  await updateStats();

  // Set up event listeners
  setupEventListeners();
});

// Load settings from storage
async function loadSettings() {
  const settings = await StorageManager.getSettings();

  document.getElementById('apiKey').value = settings.apiKey || '';
  document.getElementById('targetLanguage').value = settings.targetLanguage || 'zh-CN';
  document.getElementById('sourceLanguage').value = settings.sourceLanguage || 'en';
  document.getElementById('autoTranslate').checked = settings.autoTranslate !== false;
  document.getElementById('showTooltips').checked = settings.showTooltips !== false;
  document.getElementById('youtubeSubtitles').checked = settings.youtubeSubtitles !== false;

  // Load excluded URLs
  const excludedUrls = settings.excludedUrls || [];
  document.getElementById('excludedUrls').value = excludedUrls.join('\n');

  // Update language hint
  updateLanguageHint(settings.sourceLanguage, settings.targetLanguage);
}

// Load and display known words
async function loadWords() {
  const knownWords = await StorageManager.getKnownWords();
  displayWords(knownWords);
}

// Update language hint display
function updateLanguageHint(sourceLang, targetLang) {
  const languageNames = {
    'en': 'English',
    'es': 'Spanish',
    'fr': 'French',
    'de': 'German',
    'ja': 'Japanese',
    'ko': 'Korean',
    'it': 'Italian',
    'pt': 'Portuguese',
    'ru': 'Russian',
    'zh-CN': 'Chinese (Simplified)',
    'zh-TW': 'Chinese (Traditional)',
    'ar': 'Arabic',
    'hi': 'Hindi'
  };

  document.getElementById('sourceLangName').textContent = languageNames[sourceLang] || sourceLang;
  document.getElementById('targetLangName').textContent = languageNames[targetLang] || targetLang;
}

// Display words in the list
function displayWords(knownWords, filterText = '') {
  const wordsList = document.getElementById('wordsList');
  wordsList.innerHTML = '';

  const words = Object.values(knownWords);

  if (words.length === 0) {
    wordsList.innerHTML = '<p class="empty-state">No words saved yet. Select and translate words on any webpage to get started!</p>';
    return;
  }

  // Filter words if search text provided
  const filteredWords = filterText
    ? words.filter(w =>
        w.original.toLowerCase().includes(filterText.toLowerCase()) ||
        w.translation.toLowerCase().includes(filterText.toLowerCase())
      )
    : words;

  // Sort by most recently seen
  filteredWords.sort((a, b) => b.lastSeen - a.lastSeen);

  // Display words
  filteredWords.forEach(wordData => {
    const wordItem = document.createElement('div');
    wordItem.className = 'word-item';

    const wordInfo = document.createElement('div');
    wordInfo.className = 'word-info';

    const original = document.createElement('div');
    original.className = 'word-original';
    original.textContent = wordData.original;

    const translation = document.createElement('div');
    translation.className = 'word-translation';
    translation.textContent = wordData.translation;

    const meta = document.createElement('div');
    meta.className = 'word-meta';
    meta.textContent = `Seen ${wordData.timesEncountered} time${wordData.timesEncountered !== 1 ? 's' : ''}`;

    wordInfo.appendChild(original);
    wordInfo.appendChild(translation);
    wordInfo.appendChild(meta);

    const editBtn = document.createElement('button');
    editBtn.className = 'word-edit';
    editBtn.innerHTML = '✎';
    editBtn.title = 'Edit translation';
    editBtn.addEventListener('click', () => {
      editWord(wordItem, wordData);
    });

    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'word-delete';
    deleteBtn.innerHTML = '×';
    deleteBtn.title = 'Remove word';
    deleteBtn.addEventListener('click', async () => {
      await StorageManager.removeWord(wordData.original);
      await loadWords();
      await updateStats();
      showStatus('Word removed', 'success');
      notifyContentScripts();
    });

    wordItem.appendChild(wordInfo);
    wordItem.appendChild(editBtn);
    wordItem.appendChild(deleteBtn);
    wordsList.appendChild(wordItem);
  });

  if (filteredWords.length === 0 && filterText) {
    wordsList.innerHTML = '<p class="empty-state">No words match your search.</p>';
  }
}

// Edit a word's translation
function editWord(wordItem, wordData) {
  // Prevent multiple edits
  if (wordItem.classList.contains('editing')) {
    return;
  }

  wordItem.classList.add('editing');

  // Create edit form
  const editForm = document.createElement('div');
  editForm.className = 'edit-inputs';

  const translationInput = document.createElement('input');
  translationInput.type = 'text';
  translationInput.value = wordData.translation;
  translationInput.placeholder = 'New translation';

  const editActions = document.createElement('div');
  editActions.className = 'edit-actions';

  const saveBtn = document.createElement('button');
  saveBtn.className = 'btn btn-primary';
  saveBtn.textContent = 'Save';
  saveBtn.addEventListener('click', async () => {
    const newTranslation = translationInput.value.trim();
    if (!newTranslation) {
      showStatus('Translation cannot be empty', 'error');
      return;
    }

    await StorageManager.updateWord(wordData.original, newTranslation);
    await loadWords();
    showStatus('Translation updated', 'success');
    notifyContentScripts();
  });

  const cancelBtn = document.createElement('button');
  cancelBtn.className = 'btn btn-secondary';
  cancelBtn.textContent = 'Cancel';
  cancelBtn.addEventListener('click', async () => {
    await loadWords();
  });

  editActions.appendChild(saveBtn);
  editActions.appendChild(cancelBtn);
  editForm.appendChild(translationInput);
  editForm.appendChild(editActions);

  wordItem.appendChild(editForm);

  // Focus the input
  translationInput.focus();
  translationInput.select();
}

// Update statistics
async function updateStats() {
  const stats = await StorageManager.getStats();

  document.getElementById('wordCount').textContent = stats.totalWords;
  document.getElementById('encounterCount').textContent = stats.totalEncounters;
}

// Set up event listeners
function setupEventListeners() {
  // Save settings button
  document.getElementById('saveSettings').addEventListener('click', async () => {
    // Parse excluded URLs
    const excludedUrlsText = document.getElementById('excludedUrls').value.trim();
    const excludedUrls = excludedUrlsText
      ? excludedUrlsText.split('\n').map(url => url.trim()).filter(url => url.length > 0)
      : [];

    const settings = {
      apiKey: document.getElementById('apiKey').value.trim(),
      targetLanguage: document.getElementById('targetLanguage').value,
      sourceLanguage: document.getElementById('sourceLanguage').value,
      autoTranslate: document.getElementById('autoTranslate').checked,
      showTooltips: document.getElementById('showTooltips').checked,
      youtubeSubtitles: document.getElementById('youtubeSubtitles').checked,
      excludedUrls: excludedUrls
    };

    if (!settings.apiKey) {
      showStatus('Please enter a valid API key', 'error');
      return;
    }

    await StorageManager.updateSettings(settings);
    showStatus('Settings saved successfully!', 'success');

    // Update language hint
    updateLanguageHint(settings.sourceLanguage, settings.targetLanguage);

    // Notify content scripts to refresh
    notifyContentScripts();
  });

  // Translate & Add button
  document.getElementById('translateAndAdd').addEventListener('click', async () => {
    const word = document.getElementById('quickWord').value.trim();

    if (!word) {
      showStatus('Please enter a word', 'error');
      return;
    }

    const settings = await StorageManager.getSettings();
    if (!settings.apiKey) {
      showStatus('Please add Google Translate API key in settings first', 'error');
      return;
    }

    try {
      // Show loading state
      const btn = document.getElementById('translateAndAdd');
      const originalText = btn.textContent;
      btn.textContent = 'Translating...';
      btn.disabled = true;

      // Call translation API via background script
      const response = await chrome.runtime.sendMessage({
        action: 'translate',
        text: word,
        sourceLang: settings.sourceLanguage,
        targetLang: settings.targetLanguage
      });

      if (response.error) {
        throw new Error(response.error);
      }

      // Fill translation field
      document.getElementById('quickTranslation').value = response.translation;

      // Add to storage
      await StorageManager.addWord(word, response.translation);

      // Clear inputs
      document.getElementById('quickWord').value = '';
      document.getElementById('quickTranslation').value = '';

      // Refresh display
      await loadWords();
      await updateStats();

      showStatus(`Added: ${word} → ${response.translation}`, 'success');
      notifyContentScripts();

      // Restore button
      btn.textContent = originalText;
      btn.disabled = false;
    } catch (error) {
      showStatus(`Translation failed: ${error.message}`, 'error');
      const btn = document.getElementById('translateAndAdd');
      btn.textContent = 'Translate & Add';
      btn.disabled = false;
    }
  });

  // Add Manually button
  document.getElementById('addManually').addEventListener('click', async () => {
    const word = document.getElementById('quickWord').value.trim();
    const translation = document.getElementById('quickTranslation').value.trim();

    if (!word) {
      showStatus('Please enter a word', 'error');
      return;
    }

    if (!translation) {
      showStatus('Please enter a translation', 'error');
      return;
    }

    // Add to storage
    await StorageManager.addWord(word, translation);

    // Clear inputs
    document.getElementById('quickWord').value = '';
    document.getElementById('quickTranslation').value = '';

    // Refresh display
    await loadWords();
    await updateStats();

    showStatus(`Added: ${word} → ${translation}`, 'success');
    notifyContentScripts();
  });

  // Search words
  document.getElementById('searchWords').addEventListener('input', async (e) => {
    const filterText = e.target.value;
    const knownWords = await StorageManager.getKnownWords();
    displayWords(knownWords, filterText);
  });

  // Export words
  document.getElementById('exportWords').addEventListener('click', async () => {
    try {
      const jsonData = await StorageManager.exportWords();

      // Create blob and download
      const blob = new Blob([jsonData], { type: 'application/json' });
      const url = URL.createObjectURL(blob);

      const a = document.createElement('a');
      a.href = url;
      a.download = `language-learner-words-${Date.now()}.json`;
      a.click();

      URL.revokeObjectURL(url);

      showStatus('Words exported successfully!', 'success');
    } catch (error) {
      showStatus(`Export failed: ${error.message}`, 'error');
    }
  });

  // Import words
  document.getElementById('importFile').addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    try {
      const text = await file.text();
      const count = await StorageManager.importWords(text);

      await loadWords();
      await updateStats();

      showStatus(`Successfully imported ${count} words!`, 'success');

      // Clear file input
      e.target.value = '';

      // Notify content scripts
      notifyContentScripts();
    } catch (error) {
      showStatus(`Import failed: ${error.message}`, 'error');
    }
  });

  // Clear all words
  document.getElementById('clearWords').addEventListener('click', async () => {
    if (confirm('Are you sure you want to delete all saved words? This cannot be undone.')) {
      await StorageManager.clearAllWords();
      await loadWords();
      await updateStats();
      showStatus('All words cleared', 'success');
      notifyContentScripts();
    }
  });

  // Listen for storage changes
  chrome.storage.onChanged.addListener(async (changes, areaName) => {
    if (areaName === 'local' && changes.knownWords) {
      await loadWords();
      await updateStats();
    }
  });
}

// Show status message
function showStatus(message, type = 'info') {
  const statusElement = document.getElementById('status');
  statusElement.textContent = message;
  statusElement.className = `status ${type}`;
  statusElement.style.display = 'block';

  setTimeout(() => {
    statusElement.style.display = 'none';
  }, 3000);
}

// Notify all content scripts to refresh
function notifyContentScripts() {
  chrome.tabs.query({}, (tabs) => {
    tabs.forEach((tab) => {
      chrome.tabs.sendMessage(tab.id, {
        action: 'refreshTranslations'
      }).catch(() => {
        // Ignore errors for tabs without content script
      });
    });
  });
}

// Keyboard shortcuts
document.addEventListener('keydown', (e) => {
  // Ctrl/Cmd + S to save settings
  if ((e.ctrlKey || e.metaKey) && e.key === 's') {
    e.preventDefault();
    document.getElementById('saveSettings').click();
  }

  // Ctrl/Cmd + F to focus search
  if ((e.ctrlKey || e.metaKey) && e.key === 'f') {
    e.preventDefault();
    document.getElementById('searchWords').focus();
  }
});
