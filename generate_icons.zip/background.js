// Background Service Worker for Language Learning Extension
// Handles context menus, API calls, and inter-script communication

importScripts('translator.js');

// Load translation cache when service worker starts
TranslatorAPI.loadCacheFromStorage().then(() => {
  console.log('Translation cache loaded');
}).catch(error => {
  console.error('Failed to load translation cache:', error);
});

// Initialize extension on install
chrome.runtime.onInstalled.addListener(async (details) => {
  console.log('Language Learning Extension installed:', details.reason);

  // Load translation cache
  await TranslatorAPI.loadCacheFromStorage();

  // Initialize storage
  const result = await chrome.storage.local.get(['knownWords', 'settings']);

  if (!result.knownWords) {
    await chrome.storage.local.set({ knownWords: {} });
  }

  if (!result.settings) {
    await chrome.storage.local.set({
      settings: {
        targetLanguage: 'zh-CN',
        sourceLanguage: 'en',
        apiKey: '',
        mode: 'learn',
        autoTranslate: true,
        showTooltips: true
      }
    });
  }

  // Create context menu for translating selected text
  chrome.contextMenus.create({
    id: 'translate-and-save',
    title: 'Translate & Save Word',
    contexts: ['selection']
  });

  chrome.contextMenus.create({
    id: 'translate-only',
    title: 'Translate (Don\'t Save)',
    contexts: ['selection']
  });
});

// Handle context menu clicks
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  const selectedText = info.selectionText?.trim();

  if (!selectedText) return;

  const settings = await getSettings();

  if (info.menuItemId === 'translate-and-save') {
    await translateAndSave(selectedText, settings, tab.id);
  } else if (info.menuItemId === 'translate-only') {
    await translateOnly(selectedText, settings, tab.id);
  }
});

// Translate selected text and save to known words
async function translateAndSave(text, settings, tabId) {
  try {
    if (!settings.apiKey) {
      chrome.tabs.sendMessage(tabId, {
        action: 'showNotification',
        message: 'Please set your Google Translate API key in extension settings',
        type: 'error'
      });
      return;
    }

    // Show loading notification
    chrome.tabs.sendMessage(tabId, {
      action: 'showNotification',
      message: `Translating "${text}"...`,
      type: 'info'
    });

    // Translate the text
    const result = await TranslatorAPI.translate(
      text,
      settings.targetLanguage,
      settings.sourceLanguage,
      settings.apiKey
    );

    // Save to storage
    const knownWords = await getKnownWords();
    const wordKey = text.toLowerCase();

    if (knownWords[wordKey]) {
      knownWords[wordKey].timesEncountered++;
      knownWords[wordKey].lastSeen = Date.now();
    } else {
      knownWords[wordKey] = {
        original: text,
        translation: result.translatedText,
        dateAdded: Date.now(),
        lastSeen: Date.now(),
        timesEncountered: 1,
        sourceLanguage: result.sourceLanguage
      };
    }

    await chrome.storage.local.set({ knownWords });

    // Show success notification
    chrome.tabs.sendMessage(tabId, {
      action: 'showNotification',
      message: `✓ "${text}" → "${result.translatedText}" saved!`,
      type: 'success'
    });

    // Trigger page refresh to apply translation
    chrome.tabs.sendMessage(tabId, {
      action: 'refreshTranslations'
    });

  } catch (error) {
    console.error('Translation error:', error);
    chrome.tabs.sendMessage(tabId, {
      action: 'showNotification',
      message: `Translation failed: ${error.message}`,
      type: 'error'
    });
  }
}

// Translate without saving
async function translateOnly(text, settings, tabId) {
  try {
    if (!settings.apiKey) {
      chrome.tabs.sendMessage(tabId, {
        action: 'showNotification',
        message: 'Please set your Google Translate API key in extension settings',
        type: 'error'
      });
      return;
    }

    const result = await TranslatorAPI.translate(
      text,
      settings.targetLanguage,
      settings.sourceLanguage,
      settings.apiKey
    );

    chrome.tabs.sendMessage(tabId, {
      action: 'showNotification',
      message: `"${text}" → "${result.translatedText}"`,
      type: 'info',
      duration: 5000
    });

  } catch (error) {
    console.error('Translation error:', error);
    chrome.tabs.sendMessage(tabId, {
      action: 'showNotification',
      message: `Translation failed: ${error.message}`,
      type: 'error'
    });
  }
}

// Handle messages from content scripts and popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'translate') {
    handleTranslateRequest(request, sendResponse);
    return true; // Async response
  } else if (request.action === 'translateBatch') {
    handleTranslateBatchRequest(request, sendResponse);
    return true;
  } else if (request.action === 'getSettings') {
    getSettings().then(sendResponse);
    return true;
  } else if (request.action === 'getKnownWords') {
    getKnownWords().then(sendResponse);
    return true;
  }
});

// Handle single translation request
async function handleTranslateRequest(request, sendResponse) {
  try {
    const settings = await getSettings();

    if (!settings.apiKey) {
      sendResponse({ error: 'API key not configured' });
      return;
    }

    const result = await TranslatorAPI.translate(
      request.text,
      request.targetLang || settings.targetLanguage,
      request.sourceLang || settings.sourceLanguage,
      settings.apiKey
    );

    sendResponse({ success: true, result });
  } catch (error) {
    sendResponse({ error: error.message });
  }
}

// Handle batch translation request
async function handleTranslateBatchRequest(request, sendResponse) {
  try {
    const settings = await getSettings();

    if (!settings.apiKey) {
      sendResponse({ error: 'API key not configured' });
      return;
    }

    const results = await TranslatorAPI.translateBatch(
      request.texts,
      request.targetLang || settings.targetLanguage,
      request.sourceLang || settings.sourceLanguage,
      settings.apiKey
    );

    sendResponse({ success: true, results });
  } catch (error) {
    sendResponse({ error: error.message });
  }
}

// Helper functions
async function getSettings() {
  const result = await chrome.storage.local.get(['settings']);
  return result.settings || {};
}

async function getKnownWords() {
  const result = await chrome.storage.local.get(['knownWords']);
  return result.knownWords || {};
}

// Listen for storage changes and notify content scripts
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === 'local') {
    // Notify all tabs about storage changes
    chrome.tabs.query({}, (tabs) => {
      tabs.forEach((tab) => {
        chrome.tabs.sendMessage(tab.id, {
          action: 'storageChanged',
          changes: changes
        }).catch(() => {
          // Ignore errors for tabs without content script
        });
      });
    });
  }
});

console.log('Language Learning Extension background script loaded');
