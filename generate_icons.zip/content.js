// Content Script for Language Learning Extension
// Handles DOM manipulation and automatic word translation

(function() {
  'use strict';

  // State
  let knownWords = {};
  let settings = {};
  let isInitialized = false;
  let processedNodes = new WeakSet();
  let observer = null;

  // Notification element
  let notificationElement = null;

  // Elements to skip (won't translate these)
  const SKIP_TAGS = new Set(['SCRIPT', 'STYLE', 'NOSCRIPT', 'IFRAME', 'OBJECT', 'EMBED', 'INPUT', 'TEXTAREA', 'SELECT', 'BUTTON', 'CODE', 'PRE']);
  const SKIP_ATTRIBUTES = ['data-translated', 'contenteditable'];

  // Check if current URL is excluded
  function isUrlExcluded(currentUrl, excludedUrls) {
    if (!excludedUrls || excludedUrls.length === 0) {
      return false;
    }

    const hostname = new URL(currentUrl).hostname;

    return excludedUrls.some(excludedPattern => {
      // Normalize the pattern
      const pattern = excludedPattern.toLowerCase().trim();

      // Check if hostname contains the pattern
      if (hostname.includes(pattern)) {
        return true;
      }

      // Check if pattern matches any part of the full URL
      if (currentUrl.toLowerCase().includes(pattern)) {
        return true;
      }

      return false;
    });
  }

  // Initialize the extension
  async function initialize() {
    if (isInitialized) return;

    console.log('Language Learning Extension: Initializing...');

    // Load settings and known words
    await loadData();

    // Check if current URL is excluded
    if (settings.excludedUrls && isUrlExcluded(window.location.href, settings.excludedUrls)) {
      console.log('Language Learning Extension: Skipping excluded URL');
      return;
    }

    if (settings.autoTranslate) {
      // Start processing the page
      processPage();

      // Set up mutation observer for dynamic content
      setupMutationObserver();
    }

    isInitialized = true;
    console.log('Language Learning Extension: Ready');
  }

  // Load settings and known words from storage
  async function loadData() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['settings', 'knownWords'], (data) => {
        settings = data.settings || {};
        knownWords = data.knownWords || {};
        console.log(`Loaded ${Object.keys(knownWords).length} known words`);
        resolve();
      });
    });
  }

  // Process the entire page
  function processPage() {
    if (!settings.autoTranslate) return;

    const start = performance.now();

    // Detect page language
    const pageLanguage = detectPageLanguage();
    console.log('Page language detected:', pageLanguage);

    // Determine translation mode
    const mode = determineMode(pageLanguage);

    if (mode === 'learn') {
      // Translate known words to target language
      translateKnownWords();
    } else if (mode === 'practice') {
      // Translate all words except known ones
      translateUnknownWords();
    }

    const elapsed = performance.now() - start;
    console.log(`Page processed in ${elapsed.toFixed(2)}ms`);
  }

  // Detect the language of the page
  function detectPageLanguage() {
    // Check HTML lang attribute
    const htmlLang = document.documentElement.lang;
    if (htmlLang) {
      return htmlLang.split('-')[0].toLowerCase();
    }

    // Check meta tags
    const metaLang = document.querySelector('meta[http-equiv="content-language"]');
    if (metaLang) {
      return metaLang.content.split('-')[0].toLowerCase();
    }

    // Sample text from page
    const sampleText = document.body.innerText.substring(0, 200);

    // Simple detection based on character sets
    if (/[\u4e00-\u9fa5]/.test(sampleText)) return 'zh';
    if (/[\u3040-\u309f\u30a0-\u30ff]/.test(sampleText)) return 'ja';
    if (/[\uac00-\ud7af]/.test(sampleText)) return 'ko';
    if (/[\u0600-\u06ff]/.test(sampleText)) return 'ar';
    if (/[\u0400-\u04ff]/.test(sampleText)) return 'ru';

    // Default to English
    return 'en';
  }

  // Determine which mode to use (learn or practice)
  function determineMode(pageLanguage) {
    const targetLangCode = settings.targetLanguage?.split('-')[0].toLowerCase();
    const sourceLangCode = settings.sourceLanguage?.split('-')[0].toLowerCase();

    // If page is in source language (e.g., English), translate known words to target
    if (pageLanguage === sourceLangCode) {
      return 'learn';
    }

    // If page is in target language (e.g., Chinese), translate unknown words to source
    if (pageLanguage === targetLangCode) {
      return 'practice';
    }

    // Default to settings mode
    return settings.mode || 'learn';
  }

  // Translate known words to target language (learn mode)
  function translateKnownWords() {
    const wordList = Object.keys(knownWords);
    if (wordList.length === 0) return;

    // Create regex pattern for all known words (case-insensitive, whole words only)
    const escapedWords = wordList.map(w => escapeRegex(w));
    const pattern = new RegExp(`\\b(${escapedWords.join('|')})\\b`, 'gi');

    // Walk through all text nodes
    walkTextNodes(document.body, (textNode) => {
      if (processedNodes.has(textNode)) return;

      const originalText = textNode.textContent;
      const matches = originalText.match(pattern);

      if (matches && matches.length > 0) {
        replaceTextNode(textNode, originalText, pattern, 'learn');
        processedNodes.add(textNode);
      }
    });
  }

  // Translate unknown words to source language (practice mode)
  function translateUnknownWords() {
    // For practice mode, we would translate all text except known words
    // This is more complex and requires API calls, so we'll mark words differently

    console.log('Practice mode: Marking known words...');

    const wordList = Object.keys(knownWords).map(w => knownWords[w].translation);
    if (wordList.length === 0) {
      console.log('No known words to preserve');
      return;
    }

    // Create pattern for known translations (these we DON'T translate)
    const escapedWords = wordList.map(w => escapeRegex(w));
    const pattern = new RegExp(`(${escapedWords.join('|')})`, 'g');

    walkTextNodes(document.body, (textNode) => {
      if (processedNodes.has(textNode)) return;

      const originalText = textNode.textContent;
      const matches = originalText.match(pattern);

      if (matches) {
        // Mark known words (don't translate these)
        highlightKnownWords(textNode, originalText, pattern);
        processedNodes.add(textNode);
      }
    });
  }

  // Replace text node with translated content
  function replaceTextNode(textNode, originalText, pattern, mode) {
    const fragment = document.createDocumentFragment();
    let lastIndex = 0;
    let match;

    // Reset regex
    pattern.lastIndex = 0;

    while ((match = pattern.exec(originalText)) !== null) {
      const matchedWord = match[0];
      const wordKey = matchedWord.toLowerCase();
      const wordData = knownWords[wordKey];

      if (!wordData) continue;

      // Add text before match
      if (match.index > lastIndex) {
        fragment.appendChild(
          document.createTextNode(originalText.slice(lastIndex, match.index))
        );
      }

      // Create translated span
      const span = document.createElement('span');
      span.className = 'lang-learner-translated';
      span.textContent = wordData.translation;
      span.setAttribute('data-original', matchedWord);
      span.setAttribute('data-translated', 'true');
      span.style.cssText = 'text-decoration: underline dotted; cursor: help; color: inherit;';

      // Add tooltip on hover
      if (settings.showTooltips) {
        span.title = `Original: ${matchedWord}`;

        // Better tooltip with custom element
        span.addEventListener('mouseenter', (e) => {
          showTooltip(e.target, matchedWord);
        });

        span.addEventListener('mouseleave', () => {
          hideTooltip();
        });
      }

      fragment.appendChild(span);
      lastIndex = pattern.lastIndex;
    }

    // Add remaining text
    if (lastIndex < originalText.length) {
      fragment.appendChild(
        document.createTextNode(originalText.slice(lastIndex))
      );
    }

    // Replace the text node with the fragment
    textNode.parentNode.replaceChild(fragment, textNode);
  }

  // Highlight known words in practice mode
  function highlightKnownWords(textNode, originalText, pattern) {
    const fragment = document.createDocumentFragment();
    let lastIndex = 0;
    let match;

    pattern.lastIndex = 0;

    while ((match = pattern.exec(originalText)) !== null) {
      const matchedWord = match[0];

      // Add text before match
      if (match.index > lastIndex) {
        fragment.appendChild(
          document.createTextNode(originalText.slice(lastIndex, match.index))
        );
      }

      // Highlight known word
      const span = document.createElement('span');
      span.className = 'lang-learner-known';
      span.textContent = matchedWord;
      span.setAttribute('data-known', 'true');
      span.style.cssText = 'background-color: rgba(76, 175, 80, 0.2); padding: 0 2px; border-radius: 2px;';
      span.title = 'Known word';

      fragment.appendChild(span);
      lastIndex = pattern.lastIndex;
    }

    // Add remaining text
    if (lastIndex < originalText.length) {
      fragment.appendChild(
        document.createTextNode(originalText.slice(lastIndex))
      );
    }

    textNode.parentNode.replaceChild(fragment, textNode);
  }

  // Walk through all text nodes in the DOM
  function walkTextNodes(root, callback) {
    const walker = document.createTreeWalker(
      root,
      NodeFilter.SHOW_TEXT,
      {
        acceptNode: function(node) {
          // Skip empty nodes
          if (!node.textContent.trim()) {
            return NodeFilter.FILTER_REJECT;
          }

          // Skip elements we don't want to translate
          let parent = node.parentElement;
          while (parent) {
            if (SKIP_TAGS.has(parent.tagName)) {
              return NodeFilter.FILTER_REJECT;
            }

            // Skip if parent has skip attributes
            for (const attr of SKIP_ATTRIBUTES) {
              if (parent.hasAttribute(attr)) {
                return NodeFilter.FILTER_REJECT;
              }
            }

            parent = parent.parentElement;
          }

          return NodeFilter.FILTER_ACCEPT;
        }
      }
    );

    let node;
    while (node = walker.nextNode()) {
      callback(node);
    }
  }

  // Set up mutation observer for dynamic content
  function setupMutationObserver() {
    if (observer) return;

    observer = new MutationObserver((mutations) => {
      let shouldProcess = false;

      for (const mutation of mutations) {
        if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
          shouldProcess = true;
          break;
        }
      }

      if (shouldProcess) {
        // Debounce processing
        clearTimeout(setupMutationObserver.timeout);
        setupMutationObserver.timeout = setTimeout(() => {
          processPage();
        }, 500);
      }
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }

  // Show custom tooltip
  function showTooltip(element, text) {
    hideTooltip();

    const tooltip = document.createElement('div');
    tooltip.id = 'lang-learner-tooltip';
    tooltip.textContent = text;
    tooltip.style.cssText = `
      position: absolute;
      background: rgba(0, 0, 0, 0.9);
      color: white;
      padding: 6px 10px;
      border-radius: 4px;
      font-size: 12px;
      z-index: 999999;
      pointer-events: none;
      white-space: nowrap;
    `;

    document.body.appendChild(tooltip);

    const rect = element.getBoundingClientRect();
    tooltip.style.left = `${rect.left + window.scrollX}px`;
    tooltip.style.top = `${rect.bottom + window.scrollY + 5}px`;
  }

  // Hide tooltip
  function hideTooltip() {
    const tooltip = document.getElementById('lang-learner-tooltip');
    if (tooltip) {
      tooltip.remove();
    }
  }

  // Show notification
  function showNotification(message, type = 'info', duration = 3000) {
    hideNotification();

    notificationElement = document.createElement('div');
    notificationElement.id = 'lang-learner-notification';
    notificationElement.textContent = message;

    const colors = {
      info: '#2196F3',
      success: '#4CAF50',
      error: '#F44336'
    };

    notificationElement.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: ${colors[type] || colors.info};
      color: white;
      padding: 12px 20px;
      border-radius: 4px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.2);
      z-index: 999999;
      font-size: 14px;
      max-width: 300px;
      animation: slideIn 0.3s ease-out;
    `;

    // Add animation
    const style = document.createElement('style');
    style.textContent = `
      @keyframes slideIn {
        from { transform: translateX(400px); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
      }
    `;
    document.head.appendChild(style);

    document.body.appendChild(notificationElement);

    if (duration > 0) {
      setTimeout(hideNotification, duration);
    }
  }

  // Hide notification
  function hideNotification() {
    if (notificationElement) {
      notificationElement.remove();
      notificationElement = null;
    }
  }

  // Escape regex special characters
  function escapeRegex(string) {
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  // Listen for messages from background script
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'refreshTranslations') {
      loadData().then(() => {
        // Clear processed nodes
        processedNodes = new WeakSet();
        // Re-process page
        processPage();
      });
    } else if (request.action === 'showNotification') {
      showNotification(request.message, request.type, request.duration);
    } else if (request.action === 'storageChanged') {
      // Reload data when storage changes
      loadData().then(() => {
        processedNodes = new WeakSet();
        processPage();
      });
    }
  });

  // Initialize when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialize);
  } else {
    initialize();
  }

})();
